
#include <jni.h>
#include <dlfcn.h>
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <time.h>
#include <errno.h>
#include <fcntl.h>
#include <elf.h>
#include <android/log.h>

#include "dobby.h"
#include "Check.h" 

JavaVM* g_vm = nullptr;


static int g_debug_enabled = 0;   

#ifdef LOGI
#undef LOGI
#endif
#ifdef LOGW
#undef LOGW
#endif
#ifdef LOGD
#undef LOGD
#endif

#define TAG "CurlHookUltra"
#define LOGI(fmt, ...) do { if(g_debug_enabled) __android_log_print(ANDROID_LOG_INFO, TAG, fmt, ##__VA_ARGS__); } while(0)
#define LOGW(fmt, ...) do { if(g_debug_enabled) __android_log_print(ANDROID_LOG_WARN, TAG, fmt, ##__VA_ARGS__); } while(0)
#define LOGD(fmt, ...) do { if(g_debug_enabled) __android_log_print(ANDROID_LOG_DEBUG, TAG, fmt, ##__VA_ARGS__); } while(0)


static const char* TARGET_MODULE = "libCODMNCZ56";

static const char NEW_URL[] = "https://zxx.alwaysdata.net/connect";

static const char *OLD_PATTERNS[] = {
    "old-api.com",
    NULL
};

static const char *EXCLUDED_LIBS[] = {
    "libPixFFmpeg.so",
    "libanogs.so",
    "libPxKit3.so",
    "libgcloud.so",
    "libunity.so",
    "libAkSoundEngine.so",
    "libMSDKPIXCore.so",
    "libGCloudVoice.so",
    NULL
};

// ✅ เพิ่มที่อยู่ไฟล์ที่ต้องการสแกน
static const char *STORAGE_LIB_PATHS[] = {
    "/storage/emulated/0/Android/data/com.gspace.android/virtual/0/com.mobile.legends/files/dragon2017/assets/comlibs/arm64-v8a/librudp.bytes",
    
    // ✅ เพิ่มไฟล์อื่นๆ ตามต้องการ (ถ้ามี)
    
    NULL  // ⚠️ ต้องมี NULL ที่ท้าย
};
// ✅ เพิ่ม array นี้ (อยู่หลัง STORAGE_LIB_PATHS[])
static const size_t EXCLUDED_OFFSETS[] = {
    0x18c46c,
    0x18b6a4,
    0x18f538,// ← offset ที่ต้องข้าม
    0          // end marker
};

static int is_offset_excluded(size_t offset) {
    for (int i = 0; EXCLUDED_OFFSETS[i] != 0; i++) {
        if (offset == EXCLUDED_OFFSETS[i]) {
            return 1;
        }
    }
    return 0;
}
// ╔════════════════════════════════════════════════════════════╗
// ║              CONTROL PANEL - EDIT HERE ONLY               ║
// ╚════════════════════════════════════════════════════════════╝

static int g_whitelist_mode = 0;      // 0=แพตช์ทั้งหมด, 1=แค่ whitelist
static int g_storage_scan_mode = 0;   // 0=ไม่สแกนดิสก์, 1=สแกนดิสก์
static int g_exclude_offset_mode = 0; // 0=แพตช์ทุก offset, 1=ข้าม 0x0018c46c

// ╔════════════════════════════════════════════════════════════╗
// ║ อธิบาย:                                                    ║
// ║ • g_whitelist_mode = 0                                     ║
// ║   → แพตช์ทุก library (EXCLUDED_LIBS เท่านั้น)              ║
// ║                                                            ║
// ║ • g_whitelist_mode = 1                                     ║
// ║   → แพตช์แค่ WHITELIST_LIBS (librudp.bytes, etc)            ║
// ║                                                            ║
// ║ • g_storage_scan_mode = 0                                  ║
// ║   → ปิด: ไม่อ่านไฟล์จากดิสก์                                ║
// ║                                                            ║
// ║ • g_storage_scan_mode = 1                                  ║
// ║   → เปิด: อ่านไฟล์จาก /storage/emulated/0 ด้วย            ║
// ║                                                            ║
// ║ • g_exclude_offset_mode = 0                                ║
// ║   → ปิด: แพตช์ 0x0018c46c ปกติ                             ║
// ║                                                            ║
// ║ • g_exclude_offset_mode = 1                                ║
// ║   → เปิด: ข้าม offset 0x0018c46c ไม่แพตช์                  ║
// ╚════════════════════════════════════════════════════════════╝

// ✅ ตัวแปรสำหรับแสดง config ที่ startup
static volatile int g_config_printed = 0;

static const char *WHITELIST_LIBS[] = {
   // "libv+++.so",
    "libCODMNCZ56",
    // เพิ่มไลบารีอื่นๆ ตามต้องการ
    NULL
};

static int is_library_whitelisted(const char *path) {
    if (!g_whitelist_mode || !path) return 1;  // ถ้า mode=0 ให้ผ่าน
    for (int i = 0; WHITELIST_LIBS[i] != NULL; i++) {
        if (strstr(path, WHITELIST_LIBS[i])) return 1;
    }
    return 0;
}

#define MAX_ANCHOR_HOOKS        512
#define MAX_NEW_HOOKS_PER_ROUND 8
#define SHUTDOWN_TIME_SEC       60

#define POLL_INITIAL_US         30000
#define POLL_FAST_US            20000


static void *g_global_new_url_ptr = NULL; 
static int g_symbol_hook_installed = 0;
static void *g_curl_easy_setopt_addr = NULL;
static pthread_mutex_t g_anchor_lock = PTHREAD_MUTEX_INITIALIZER;

static void *g_anchor_hooks[MAX_ANCHOR_HOOKS];
static int g_anchor_hook_count = 0;

static int g_hooks_this_round = 0;          
static struct timespec g_scan_start_time;   

static const uint32_t MOV_ANCHOR_PATTERN = 0x5284E241;

static const uint32_t CSEL_BASE = 0x9A800000;
static const uint32_t CSEL_MASK = 0xFFE00C00;


#define MY_ELF_ST_BIND(val) (((unsigned char)(val)) >> 4)
#define MY_ELF_ST_TYPE(val) (((unsigned char)(val)) & 0xf)

#if defined(__aarch64__) || defined(__x86_64__)
  #define ELF_EHDR    Elf64_Ehdr
  #define ELF_SHDR    Elf64_Shdr
  #define ELF_SYM     Elf64_Sym
#else
  #define ELF_EHDR    Elf32_Ehdr
  #define ELF_SHDR    Elf32_Shdr
  #define ELF_SYM     Elf32_Sym
#endif


static void init_rng(void);
static void dump_module_info(const char *filter);
static void dump_hook_status(void);
static void start_module_watcher(void);


__attribute__((constructor))
static void early_init(void) {
    init_rng();
    g_global_new_url_ptr = (void *)malloc(strlen(NEW_URL) + 1);
    if (g_global_new_url_ptr) {
        strcpy((char *)g_global_new_url_ptr, NEW_URL);
    }

    LOGI("╔══════════════════════════════════════════════╗");
    LOGI("║  CurlHook Ultra v5.2 — Stealth Adaptive    ║");
    LOGI("╚══════════════════════════════════════════════╝");
}

static void print_config(void) {
    // ✅ พิมพ์ config เพียง 1 ครั้ง (ตอน startup)
    if (g_config_printed) return;
    g_config_printed = 1;

    LOGI("╔════════════════════════════════════════════════════════════╗");
    LOGI("║          CurlHook Ultra v5.2 — Active Config              ║");
    LOGI("├════════════════════════════════════════════════════════════┤");
    LOGI("║ Whitelist Mode     : %s", 
         g_whitelist_mode ? "✓ ON (only whitelist)" : "✗ OFF (all libs)");
    LOGI("║ Storage Scan Mode  : %s", 
         g_storage_scan_mode ? "✓ ON (disk scan)" : "✗ OFF (no disk)");
    LOGI("║ Exclude Offset Mode: %s", 
         g_exclude_offset_mode ? "✓ ON (skip 0x18c46c)" : "✗ OFF (hook all)");
    LOGI("╚════════════════════════════════════════════════════════════╝");
}
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) 
{
    (void)vm;
    (void)reserved;
    
    g_vm = vm; 

  if (!Check::RunAll(vm))
    {
        return -1; // โดนเตะออก
    }

   Check::StartWatcher(vm);

    LOGI("══════════════════════════════════════════════");
    LOGI(" JNI_OnLoad — Deploying Adaptive Engine");
    LOGI("══════════════════════════════════════════════");

    dump_module_info(TARGET_MODULE);
    dump_hook_status();
 start_module_watcher();

    return JNI_VERSION_1_6;
}



typedef struct {
    void *base;           
    void *exec_start;     
    size_t exec_size;     
    char path[256];       
} ModuleInfo;

static int find_module_in_maps(const char *name, ModuleInfo *out) {
    if (!name || !out) return 0;
    memset(out, 0, sizeof(*out));

    FILE *fp = fopen("/proc/self/maps", "r");
    if (!fp) return 0;

    char line[1024];
    int found_base = 0;

    while (fgets(line, sizeof(line), fp)) {
        if (!strstr(line, name)) continue;

        uintptr_t start, end;
        char perms[5], path[256] = {0};
        
        if (sscanf(line, "%lx-%lx %4s %*s %*s %*s %255s", &start, &end, perms, path) < 3) continue;

        if (!found_base && strstr(perms, "r")) {
            out->base = (void *)start;
            strncpy(out->path, path, sizeof(out->path) - 1);
            found_base = 1;
        }

        if (found_base && strstr(perms, "x")) {
            if (!out->exec_start) out->exec_start = (void *)start;
            out->exec_size = end - (uintptr_t)out->exec_start;
        }
    }
    fclose(fp);
    return found_base;
}


static unsigned int g_seed = 0;

static void init_rng(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    g_seed = (unsigned int)(ts.tv_nsec ^ (uintptr_t)&g_seed ^ getpid());
}

static unsigned int xorshift32(void) {
    g_seed ^= g_seed << 13;
    g_seed ^= g_seed >> 17;
    g_seed ^= g_seed << 5;
    return g_seed;
}

static int is_already_hooked(void *addr) {
    if (!addr) return 0;
    uint8_t *code = (uint8_t *)addr;
    if (code[0] == 0x50 && code[1] == 0x00 && code[2] == 0x00 && code[3] == 0x58) {
        return 1;
    }
    if ((code[3] & 0xFC) == 0x14) {
        return 1;
    }
    return 0;
}

static ssize_t mem_scan_pattern(const uint8_t *buf, size_t len, const uint32_t pattern) {
    const uint32_t *u32 = (const uint32_t *)buf;
    size_t count = len / 4;
    for (size_t i = 0; i < count; i++) {
        if (u32[i] == pattern) return (ssize_t)(i * 4);
    }
    return -1;
}

static inline int is_csel_x2(uint32_t insn) {
    return ((insn & CSEL_MASK) == CSEL_BASE) && ((insn & 0x1F) == 2);
}

static int is_valid_string_pointer(uintptr_t ptr) {
    if (ptr < 0x10000000 || ptr > 0x7FFFFFFFFFFF) return 0;
    char *str = (char *)ptr;
    if (str[0] == 'h' && str[1] == 't' && str[2] == 't') return 1;
    return 0;
}

static void hijack_x2_callback(void *address, DobbyRegisterContext *ctx) {
    (void)address;
#if defined(__aarch64__) || defined(__arm64__)
    uintptr_t current_x2 = ctx->general.regs.x2;
    if (is_valid_string_pointer(current_x2)) {
        ctx->general.regs.x2 = (uint64_t)g_global_new_url_ptr;
        LOGI("[🔥 Hijacked] x2 <- new URL @ %p", (void*)address);
    }
#endif
}
static int scan_range_for_anchor(uint8_t *range_base, size_t range_size) {
    if (range_size < 4 || g_hooks_this_round >= MAX_NEW_HOOKS_PER_ROUND) return 0;

    uint8_t *buf = (uint8_t *)malloc(range_size);
    if (!buf) return 0;
    memcpy(buf, range_base, range_size);

    int found = 0;
    size_t offset = 0;

    while (offset < range_size - 4 && g_hooks_this_round < MAX_NEW_HOOKS_PER_ROUND) {
        ssize_t mov_off = mem_scan_pattern(buf + offset, range_size - offset, MOV_ANCHOR_PATTERN);
        if (mov_off < 0) break;

        size_t abs_off = offset + (size_t)mov_off;
        void *mov_addr = range_base + abs_off;
       LOGI("[DEBUG] Found pattern at offset: 0x%zx, addr: %p", abs_off, mov_addr);

if (g_exclude_offset_mode && is_offset_excluded(abs_off)) {
            LOGI("[⏭️  SKIP] Excluded offset 0x%zx @ %p", abs_off, mov_addr);
            offset = abs_off + 4;
            continue;
        }
        int valid = 0;

        if (abs_off >= 4) {
            uint32_t prev1 = *(uint32_t *)(buf + abs_off - 4);
            if (is_csel_x2(prev1)) valid = 1;
        }

        if (!valid && abs_off >= 8) {
            uint32_t prev2 = *(uint32_t *)(buf + abs_off - 8);
            if (is_csel_x2(prev2)) valid = 1;
        }

        if (valid) {
            pthread_mutex_lock(&g_anchor_lock);
            int already = 0;
            for (int i = 0; i < g_anchor_hook_count; i++) {
                if (g_anchor_hooks[i] == mov_addr) {
                    already = 1;
                    break;
                }
            }
            pthread_mutex_unlock(&g_anchor_lock);

            if (!already) {
                int ret = DobbyInstrument(mov_addr, hijack_x2_callback);
                if (ret == 0) {
                    pthread_mutex_lock(&g_anchor_lock);
                    if (g_anchor_hook_count < MAX_ANCHOR_HOOKS) {
                        g_anchor_hooks[g_anchor_hook_count++] = mov_addr;
                    }
                    pthread_mutex_unlock(&g_anchor_lock);
                    g_hooks_this_round++;
                    found++;
                    LOGI("[🎯 Hook] Instrumented @ %p (mov w1,0x2712)", mov_addr);
                } else {
                    LOGW("[⚠] DobbyInstrument failed @ %p", mov_addr);
                }
            }
        }

        offset = abs_off + 4;
    }

    free(buf);
    return found;
}


static int is_library_excluded(const char *path) {
    if (!path) return 0;
    for (int i = 0; EXCLUDED_LIBS[i] != NULL; i++) {
        if (strstr(path, EXCLUDED_LIBS[i])) return 1;
    }
    return 0;
}
static void scan_all_executable_regions(void) {
    g_hooks_this_round = 0;
    if (g_hooks_this_round >= MAX_NEW_HOOKS_PER_ROUND) return;

    FILE *fp = fopen("/proc/self/maps", "r");
    if (!fp) return;

    char line[1024];
    int total_hooked = 0;

    while (fgets(line, sizeof(line), fp) && g_hooks_this_round < MAX_NEW_HOOKS_PER_ROUND) {
        if (!strstr(line, "r-xp")) continue;

        uintptr_t start, end;
        char perms[5], path[256] = {0};
        if (sscanf(line, "%lx-%lx %4s %*s %*s %*s %255s", &start, &end, perms, path) < 3)
            continue;

        if (is_library_excluded(path)) continue;
        
        // ✅ เพิ่มตรงนี้
        if (!is_library_whitelisted(path)) {
           // LOGD("[SKIP] Whitelist mode: skipping %s", path);
            continue;
        }

        size_t size = end - start;
        if (size > 0) {
            int n = scan_range_for_anchor((uint8_t *)start, size);
            total_hooked += n;
        }
    }

    fclose(fp);
    if (total_hooked > 0) {
        LOGI("[SCAN] Added %d new anchors this round", total_hooked);
    }
}

// ╔════════════════════════════════════════════════════════════╗
// ║        STORAGE LIBRARY SCANNER (อ่านไฟล์จากดิสก์)         ║
// ╚════════════════════════════════════════════════════════════╝

static int scan_storage_library(const char *lib_path) {
    // ✅ ฟังก์ชันอ่านไฟล์ 1 ตัว
    
    if (!lib_path) return 0;

    int fd = open(lib_path, O_RDONLY);
    if (fd < 0) {
        LOGD("[STORAGE] File not found: %s (errno: %d)", lib_path, errno);
        return 0;
    }

    struct stat sb;
    if (fstat(fd, &sb) < 0) {
        LOGW("[STORAGE] fstat failed for %s", lib_path);
        close(fd);
        return 0;
    }

    size_t file_size = sb.st_size;
    if (file_size == 0 || file_size > 100 * 1024 * 1024) {
        LOGW("[STORAGE] File size invalid: %zu bytes", file_size);
        close(fd);
        return 0;
    }

    uint8_t *file_buf = (uint8_t *)malloc(file_size);
    if (!file_buf) {
        LOGW("[STORAGE] malloc failed for %zu bytes", file_size);
        close(fd);
        return 0;
    }

    // ✅ เปลี่ยนเป็น loop อ่านจนครบ
ssize_t total_read = 0;
while (total_read < (ssize_t)file_size) {
    ssize_t bytes_read = read(fd, file_buf + total_read, file_size - total_read);
    if (bytes_read <= 0) {
        if (bytes_read < 0) {
            LOGW("[STORAGE] read error: %s", strerror(errno));
        }
        break;
    }
    total_read += bytes_read;
}
close(fd);

if (total_read != (ssize_t)file_size) {
    LOGW("[STORAGE] read incomplete: got %zd, expected %zu", total_read, file_size);
    free(file_buf);
    return 0;
}

    LOGI("[✓ STORAGE] Scanning: %s (%zu bytes)", lib_path, file_size);

    int found = scan_range_for_anchor(file_buf, file_size);

    free(file_buf);
    return found;
}

static void scan_all_storage_libraries(void) {
    // ✅ ฟังก์ชันที่วนลูปอ่านทุกไฟล์ใน STORAGE_LIB_PATHS[]
    
    LOGI("[STORAGE] Starting disk scan for libraries...");
    
    int total_found = 0;
    for (int i = 0; STORAGE_LIB_PATHS[i] != NULL; i++) {
        int found = scan_storage_library(STORAGE_LIB_PATHS[i]);
        if (found > 0) {
            total_found += found;
            LOGI("[STORAGE] Found %d patterns in %s", found, STORAGE_LIB_PATHS[i]);
        }
    }
    
    if (total_found == 0) {
        LOGD("[STORAGE] No patterns found in any storage libraries");
    }
}
static void *elf_resolve_symbol(void *base_addr, const char *file_path, const char *sym_name) {
    if (!base_addr || !sym_name) return NULL;

    ELF_EHDR *ehdr = (ELF_EHDR *)base_addr;
    ELF_SHDR *shdr = NULL;
    ELF_SHDR *shstr_hdr = NULL;
    const char *shstr = NULL;
    ELF_SYM *dynsym = NULL;
    size_t dynsym_n = 0;
    const char *dynstr = NULL;

    if (memcmp(ehdr->e_ident, ELFMAG, SELFMAG) == 0) {
        shdr = (ELF_SHDR *)((uint8_t *)base_addr + ehdr->e_shoff);
        shstr_hdr = &shdr[ehdr->e_shstrndx];
        shstr = (const char *)base_addr + shstr_hdr->sh_offset;

        for (int i = 0; i < ehdr->e_shnum; i++) {
            const char *sname = shstr + shdr[i].sh_name;
            if (shdr[i].sh_type == SHT_DYNSYM) {
                dynsym = (ELF_SYM *)((uint8_t *)base_addr + shdr[i].sh_offset);
                dynsym_n = shdr[i].sh_size / sizeof(ELF_SYM);
            } else if (shdr[i].sh_type == SHT_STRTAB && strcmp(sname, ".dynstr") == 0) {
                dynstr = (const char *)((uint8_t *)base_addr + shdr[i].sh_offset);
            }
        }

        if (dynsym && dynstr) {
            for (size_t i = 0; i < dynsym_n; i++) {
                if (dynsym[i].st_name == 0 || dynsym[i].st_shndx == SHN_UNDEF) continue;
                const char *name = dynstr + dynsym[i].st_name;
                if (strcmp(name, sym_name) == 0) {
                    return (uint8_t *)base_addr + dynsym[i].st_value;
                }
            }
        }
    }

    if (file_path && file_path[0]) {
        void *handle = dlopen(file_path, RTLD_NOW);
        if (handle) {
            void *sym = dlsym(handle, sym_name);
            dlclose(handle);
            if (sym) return sym;
        }
    }

    void *handle = dlopen(TARGET_MODULE, RTLD_NOW);
    if (handle) {
        void *sym = dlsym(handle, sym_name);
        dlclose(handle);
        if (sym) return sym;
    }
    return NULL;
}

static void *resolve_in_target(const char *sym_name) {
    ModuleInfo mod;
    if (!find_module_in_maps(TARGET_MODULE, &mod)) return NULL;
    return elf_resolve_symbol(mod.base, mod.path[0] ? mod.path : NULL, sym_name);
}

#define CURLOPT_URL 10002

static int (*g_orig_curl_easy_setopt)(void *curl, int option, ...) = NULL;

static int h_curl_easy_setopt(void *curl, int option, ...) {
    va_list args;
    va_start(args, option);

    if (option == CURLOPT_URL) {
        void *url_ptr = va_arg(args, void *);
        va_end(args);

        if (url_ptr) {
            const char *url = (const char *)url_ptr;
            int matched = 0;
            for (int i = 0; OLD_PATTERNS[i]; i++) {
                if (strstr(url, OLD_PATTERNS[i])) {
                    matched = 1;
                    break;
                }
            }

            if (matched) {
                LOGI("[INTERCEPT] Old URL: %.120s", url);
                if (xorshift32() % 100 < 90) {
                    return g_orig_curl_easy_setopt(curl, option, (void *)g_global_new_url_ptr);
                }
            }
        }
        return g_orig_curl_easy_setopt(curl, option, url_ptr);
    }
    void *arg = va_arg(args, void *);
    va_end(args);
    return g_orig_curl_easy_setopt(curl, option, arg);
}

static int install_symbol_hook(void) {
    if (g_symbol_hook_installed) return 0;
    
    void *sym = resolve_in_target("curl_easy_setopt");
    if (!sym) return -1;
    
    if (is_already_hooked(sym)) {
        LOGW("[SYMBOL] Already hooked – skipping");
        return -2;
    }
    
    int ret = DobbyHook(sym, (void *)h_curl_easy_setopt, (void **)&g_orig_curl_easy_setopt);
    if (ret == 0) {
        g_symbol_hook_installed = 1;
        g_curl_easy_setopt_addr = sym;   
    }
    return ret;
}

static long get_scan_interval_us(void) {
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);
    long elapsed_ms = (now.tv_sec - g_scan_start_time.tv_sec) * 1000 +
                      (now.tv_nsec - g_scan_start_time.tv_nsec) / 1000000;

    if (elapsed_ms < 10000)       return 100000;  
    else if (elapsed_ms < 30000)  return 200000;   
       else                          return 1000000;  
}

static void cleanup_all_hooks(void) {
    pthread_mutex_lock(&g_anchor_lock);
    for (int i = 0; i < g_anchor_hook_count; i++) {
        if (g_anchor_hooks[i]) {
            DobbyDestroy(g_anchor_hooks[i]);
            g_anchor_hooks[i] = NULL;
        }
    }
    g_anchor_hook_count = 0;
    pthread_mutex_unlock(&g_anchor_lock);

    if (g_symbol_hook_installed && g_curl_easy_setopt_addr) {
        DobbyDestroy(g_curl_easy_setopt_addr);
        g_symbol_hook_installed = 0;
        g_curl_easy_setopt_addr = NULL;
    }

    LOGI("[🧹 Cleanup] All hooks destroyed");
}

static volatile int g_watcher_running = 0;
static pthread_t g_watcher_thread = 0;

static void *module_watcher(void *arg) {
    (void)arg;
    clock_gettime(CLOCK_MONOTONIC, &g_scan_start_time);
    
    // ✅ พิมพ์ config ตอนแรกที่เริ่ม
    print_config();

    while (g_watcher_running) {
        struct timespec now;
        clock_gettime(CLOCK_MONOTONIC, &now);
        long elapsed_sec = now.tv_sec - g_scan_start_time.tv_sec;
        if (elapsed_sec >= SHUTDOWN_TIME_SEC) {
            LOGI("[⏰] 90s self‑destruct – cleaning up");
            cleanup_all_hooks();
            g_watcher_running = 0;
            break;
        }

        scan_all_executable_regions();

        // ✅ ใช้ flag ตรวจสอบ
        if (g_storage_scan_mode) {
            scan_all_storage_libraries();
        }

        if (!g_symbol_hook_installed) {
            install_symbol_hook();
        }

        long interval_us = get_scan_interval_us();
        usleep((useconds_t)interval_us);
    }

    return NULL;
}

static void start_module_watcher(void) {
    if (g_watcher_running) return;
    g_watcher_running = 1;
    pthread_create(&g_watcher_thread, NULL, module_watcher, NULL);
    pthread_detach(g_watcher_thread);
}

static void dump_hook_status(void) {
    LOGI("┌──────────────────────────────────────────────┐");
    LOGI("│  CurlHook Ultra v5.2 — Status Report         │");
    LOGI("├──────────────────────────────────────────────┤");
    LOGI("│  Symbol Hook : %s", g_symbol_hook_installed ? "✓ INSTALLED" : "✗ pending");
    LOGI("│  Anchor Hooks: %d active", g_anchor_hook_count);
    LOGI("│  PID         : %d", getpid());
    LOGI("└──────────────────────────────────────────────┘");
}

static void dump_module_info(const char *filter) {
    FILE *fp = fopen("/proc/self/maps", "r");
    if (!fp) return;

    char line[1024];
    LOGI("[MAPS] Filter: %s", filter ? filter : "all");
    while (fgets(line, sizeof(line), fp)) {
        if (filter && !strstr(line, filter)) continue;
        size_t len = strlen(line);
        if (len > 0 && line[len-1] == '\n') line[len-1] = '\0';
        LOGD("  %s", line);
    }
    fclose(fp);
}

